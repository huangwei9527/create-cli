import React, { useState } from 'react'
import { Button } from 'antd-mobile'
import 'antd-mobile/es/global'
import '@/assets/iconcool/iconcool.css'
import '@/styles/common.less'

function App() {
  const [count, setCount] = useState(0)
  console.log('sdsds')
  return (
    <>
      <h1>Vite + React</h1>
      <div className="card">
        <button onClick={() => setCount(count => count + 1)}>count is {count}</button>
        <p>
          Edit <code>src/App.tsx</code> and save to test HMR
        </p>
      </div>
      <p className="read-the-docs">Click on the Vite and React logos to learn more</p>
      <Button block color="primary" size="large">
        Block Button
      </Button>
    </>
  )
}

export default App
