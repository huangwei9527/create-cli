import {
  configureStore,
  ThunkAction,
  combineReducers,
  Action,
  Reducer,
} from "@reduxjs/toolkit";
import configObj from "@/config";
import { getReducerManager } from "./reducerManager";
// 模块
import appSlice from "./modules/appSlice";
import localCacheSlice from "./modules/localCacheSlice";

const reducerManager = getReducerManager({
  app: appSlice,
  localCache: localCacheSlice,
});
export const store = configureStore({
  reducer: reducerManager.reduce,
  devTools: configObj.debuggerMode,
  middleware: (getDefaultMiddleware) => {
    return getDefaultMiddleware({
      serializableCheck: false,
    });
  },
});

export const { add, remove } = reducerManager;
export default store;

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
export type AppThunk<ReturnType = void> = ThunkAction<
  ReturnType,
  RootState,
  unknown,
  Action<string>
>;
