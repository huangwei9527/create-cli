import { createSlice } from '@reduxjs/toolkit'
import { initSystemTypeFn } from '@/utils/initSystemDataFn'
import { getBaseData } from '@/api/common'
import defaultSystemModel from '@/model/default-system-model'
export interface AppState {
  systemInitData: any
  permissions: string[] | number[]
  DBID: string | number
  hideHeader: boolean
  serviceCode: string | number
  servicePwd: string | number
  checkAgree: boolean
}

const initialState: AppState = {
  DBID: '',
  systemInitData: defaultSystemModel,
  permissions: [],
  hideHeader: false,
  serviceCode: '',
  servicePwd: '',
  checkAgree: false
}

export const appSlice = createSlice({
  name: 'app',
  initialState,
  // The `reducers` field lets us define reducers and generate associated actions
  reducers: {
    setDbId(state, action) {
      state.DBID = initSystemTypeFn(action.payload)
    },
    /**
     * 设置系统参数信息
     * @param state
     */
    setSystemInitData(state, action) {
      const systemInitData = action.payload
      state.systemInitData = systemInitData
      state.DBID = systemInitData.DBID || ''
      state.permissions = (systemInitData.rights ? JSON.parse(systemInitData.rights) : []).map(v => v['i'])
    },
    updateSystemInitDataAttr(state, action) {
      const newData = {
        ...state.systemInitData,
        ...(action.payload || {})
      }
      state.systemInitData = {
        ...newData
      }
    },
    switchHideHeader(state) {
      state.hideHeader = !state.hideHeader
    },
    // 设置服务识别码和密码
    setServiceInfo(state, action) {
      state.serviceCode = action.payload.serviceCode
      state.servicePwd = action.payload.password
    },
    // wps是否勾选协议
    setAgreement(state, action) {
      state.checkAgree = action.payload
    }
  }
})

/**
 * 获取finance index user setting数据
 * @returns 返回个Promise 支持链式获取financeIndexUserSetting
 */
export function getSystemInitDataAsync() {
  return async function (dispatch) {
    const res: any = await getBaseData()
    if (!res) {
      return null
    }
    localStorage.setItem('indexType', 'newer')
    localStorage.setItem(
      'todayDate',
      new Date().getFullYear().toString() + (new Date().getMonth() + 1).toString() + new Date().getDate().toString()
    )
    const systemInitData: any = initSystemTypeFn(res || {})
    dispatch(setSystemInitData({ ...systemInitData }))
    // 增加代理模式同步store与SYSTEM

    window['SYSTEM'] = new Proxy(
      { ...systemInitData },
      {
        set(target, key, value, receiver) {
          dispatch(updateSystemInitDataAttr({ [key]: value }))
          return Reflect.set(target, key, value, receiver)
        }
      }
    )

    return systemInitData
  }
}

export const { setSystemInitData, updateSystemInitDataAttr, switchHideHeader, setServiceInfo, setAgreement } = appSlice.actions

export default appSlice.reducer
