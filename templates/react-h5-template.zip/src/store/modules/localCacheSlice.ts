import { createSlice } from "@reduxjs/toolkit";

export interface IUserState {
  [key: string]: any;
}
const initialState: IUserState = {};

export const localCacheSlice = createSlice({
  name: "localCache",
  initialState,
  // 定义 reducers 并生成关联的操作
  reducers: {
    fetchCacheFromeLocalstorage(state) {
      let cacheData: string | any =
        window.localStorage.getItem("JDY_LOCAL_CACHE") || "{}";
      try {
        cacheData = JSON.parse(cacheData);
      } catch (e) {
        cacheData = {};
      }
      Object.keys(cacheData).forEach((key) => {
        state[key] = cacheData[key];
      });
    },

    /**
     * 更新字段key value
     * @param state
     * @param action
     * @constructor
     */
    updateLocalstorageCache(state, action) {
      const opt = action.payload;
      if (!opt) {
        return;
      }
      Object.keys(opt).forEach((key) => {
        state[key] = opt[key];
      });
      // 构造缓存数据
      let localStorageCacheData: string | any =
        window.localStorage.getItem("JDY_LOCAL_CACHE") || "{}";
      try {
        localStorageCacheData = JSON.parse(localStorageCacheData);
      } catch (e) {
        localStorageCacheData = {};
      }
      const cacheData = { ...localStorageCacheData };
      for (let key in state) {
        cacheData[key] = state[key];
      }
      window.localStorage.setItem("JDY_LOCAL_CACHE", JSON.stringify(cacheData));
    },
  },
});
export const { fetchCacheFromeLocalstorage, updateLocalstorageCache } =
  localCacheSlice.actions;

// 默认导出
export default localCacheSlice.reducer;
