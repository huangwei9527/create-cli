// 借贷方向
export const creditDebitDire = [
  { label: '借', value: 1 },
  { label: '贷', value: -1 }
]
// 科目分类
export const subjectCategory = [
  { label: '资产', value: 1 },
  { label: '负债', value: 2 },
  { label: '共同', value: 7 },
  { label: '权益', value: 3 },
  { label: '成本', value: 4 },
  { label: '损益', value: 5 }
]
