import { defineConfig, normalizePath, loadEnv } from 'vite'
import react from '@vitejs/plugin-react'
import viteEslint from 'vite-plugin-eslint'
import tsconfigPaths from 'vite-tsconfig-paths'
import path from 'path'
import autoprefixer from 'autoprefixer'
import postCssPxToRem from 'postcss-pxtorem'

// https://vitejs.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd())
  return {
    build: {
      sourcemap: !(env.VITE_ENV_NAME === 'production'),
      minify: 'terser',
      terserOptions: {
        compress: {
          //生产环境时移除debugger
          drop_debugger: true
        }
      }
    },
    define: {
      'process.env': process.env
    },
    plugins: [react(), viteEslint({ failOnError: false }), tsconfigPaths()],
    resolve: {
      alias: [
        {
          find: '@',
          replacement: path.resolve(__dirname, 'src')
        }
      ]
    },
    // css 相关的配置
    css: {
      modules: {
        generateScopedName: '[name]__[local]___[hash:base64:5]'
      },
      // LESS， 这里是 LESS 的配置可以忽略
      preprocessorOptions: {
        less: {
          javascriptEnabled: true,
          charset: false,
          globalVars: {
            // 配置Less的全局变量
            // blue:"#1CC0FF"
          }
        }
      },
      // 进行 PostCSS 配置
      postcss: {
        plugins: [
          autoprefixer({
            // 指定目标浏览器
            overrideBrowserslist: ['Android 4.1', 'iOS 7.1'],
            grid: true
          }),
          postCssPxToRem({
            rootValue: 75, // （设计稿/10）1rem的大小
            propList: ['*', '!border', '!font-size'] // 除 border/font-size 外所有px 转 rem
          })
        ]
      }
    },
    server: {
      host: true,
      port: 8080,
      proxy: {
        '/v1': {
          target: 'https://vip1.jdy.com', // 设置你调用的接口域名和端口号 别忘了加http
          changeOrigin: true, // needed for virtual hosted sites
          pathRewrite: {},
          onProxyReq
        }
      }
    }
  }
})

function onProxyReq(proxyReq: any) {
  let cookies = proxyReq.getHeader('Cookie')
  if (!cookies) return
  let matchRes = cookies.match(/ysSession=([\w._-]*);*/)
  let matchRes1 = cookies.match(/app-token=([\w._-]*);*/)
  if (matchRes && matchRes1) {
    let ysSession = matchRes[1]
    let appToken = matchRes1[1]
    if (ysSession) {
      proxyReq.setHeader('Authorization', ysSession)
      proxyReq.setHeader('app-token', appToken)
    }
  }
}
