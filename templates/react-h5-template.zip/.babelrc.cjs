module.exports = {
  plugins: [['import', { libraryName: 'antd-mobile', libraryDirectory: 'es/components', style: false }]]
}
