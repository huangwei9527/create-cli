/**
 * 页面常量
 */

// 页面name 通过分类名module和page name生成
export const PAGE_NAME = 'userInfo'
export const PAGE_NAME_CN = '个人信息'
// 页面tag
export const PAGE_TAG = { name: PAGE_NAME, version: '0.0.1' }
