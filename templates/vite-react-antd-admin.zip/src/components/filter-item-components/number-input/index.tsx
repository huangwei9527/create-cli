import React, { FC, useEffect } from 'react'

const Component: FC = () => {
  useEffect(() => {}, [])

  return <div>待完善</div>
}

export default Component
