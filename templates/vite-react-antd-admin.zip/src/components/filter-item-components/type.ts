export interface IOptions {
  label: string
  value: string | number
  [key: string]: any
}
