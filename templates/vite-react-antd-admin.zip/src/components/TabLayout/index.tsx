import Tabs from './Tabs'
import TabsItem from './TabsItem'

export default {
  Tabs,
  TabsItem
}
